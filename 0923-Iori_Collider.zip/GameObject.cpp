#include "GameObject.h"

void GameObject::Move()
{
	//singleton1.ProcessInputKey();
}

GameObject::GameObject()
{
}

GameObject::~GameObject()
{
}
