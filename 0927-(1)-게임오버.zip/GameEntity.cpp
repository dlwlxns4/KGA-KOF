#include "GameEntity.h"
#include "Singleton.h"

void GameEntity::Init()
{
	//cout << "Hello World!!" << endl;
}

void GameEntity::Update()
{
}

void GameEntity::Render(HDC hdc)
{
}

void GameEntity::Release()
{
}
